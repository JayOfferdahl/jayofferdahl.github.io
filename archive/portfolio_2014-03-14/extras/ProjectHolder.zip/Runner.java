import java.io.FileNotFoundException;

//The main class of MegaProjectHolder
//Use this class to run all the rest of the projects
public class Runner {
	
	public static void main(String[] args) throws FileNotFoundException {
		/**
		 * Projecteuler projects 
		 * Hooray
		 * So many
		 * Dear god..
		 * wow. 
		 * Such code
		 * Many command
		 * So comp sci
		 * Wow
		 */
		
		
		//PigLatinTranslator fu = new PigLatinTranslator();
		
		//EvenFibonacciNumbers fu = new EvenFibonacciNumbers();
		
		//ThreeFiveMultiples fu = new ThreeFiveMultiples();
		
		//LargestPrimeFactor fu = new LargestPrimeFactor();
		
		//LargestPalindromeProject fu = new LargestPalindromeProject();
		
		SmallestMultiple fu = new SmallestMultiple();
		
		//SumSquare fu = new SumSquare();
		
		//FindAPrime fu = new FindAPrime();
		
		//LargestFiveDigitProduct fu = new LargestFiveDigitProduct();
		
		//PythagoreanTripletFinder fu = new PythagoreanTripletFinder();
		
		//SummationOfPrimes fu = new SummationOfPrimes();
		
		//LargestGridProject fu = new LargestGridProject();
	}
}