import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class LargestGridProject {

	private final int GRIDSIZE = 20;
	
	public LargestGridProject() throws FileNotFoundException {
		File grid = new File("2020grid.txt");
		Scanner scan = new Scanner(grid);
		
		int[][] gridHolder = new int[20][20];
		
		for(int index = 0; index < GRIDSIZE; index++) {
			for(int secondIndex = 0; secondIndex < GRIDSIZE; secondIndex++) {
				gridHolder[index][secondIndex] = scan.nextInt();
				System.out.println("Added " + gridHolder[index][secondIndex]);
				
			}
		}
		
	}
}
