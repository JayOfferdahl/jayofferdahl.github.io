import java.util.*;


public class FindAPrime {

	/**
	 * Create a stack that holds all the prime numbers
	 * Start from 1 and go to infity looking for prime numbers
	 * When the stack is at the desired element (nth prime number) pop the stack and print the result
	 */
	public FindAPrime() {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the value for n to find the nth prime number.");
		int primeToFind = scan.nextInt();
		
		Stack<Double> primeHolder = new Stack<Double>();
		double currentNumber = 2;
		
		while(primeHolder.size() != primeToFind) {
			if(findFactors(currentNumber).size() <= 1)
				primeHolder.push(currentNumber);
			currentNumber++;
		}
		
		System.out.println("The " + primeToFind + "st prime number is " + primeHolder.pop());
	}
	
	public ArrayList findFactors(double input) {
		ArrayList allFactors = new ArrayList();
		
		for(int i = 1; i <= input/i; i++) {
			if(input % i == 0) {
				allFactors.add(i);
			}
		}
		
		return allFactors;
	}
}
