import java.util.*;


public class LargestPalindromeProject {
	private final int MAX_PRODUCT = 998001;
	private int one, two;
	
	public LargestPalindromeProject() {
		System.out.println("Finding the largest palindrome as a result of two three digit numbers.");
		Stack<Integer> palindromeStack = new Stack<Integer>();
		
		//Find a palindrome between 1 and 998001 MAX_PRODUCT
		for(int i = 0; i < MAX_PRODUCT; i++) {
			if(isPalindrome(i)) 
				palindromeStack.add(i);
		}
		
		int index = palindromeStack.size();
		int currentElement = 0;
		
		while(index > 0) {
			currentElement = palindromeStack.pop();
			if(hasTwoThreeDigits(findFactors(currentElement), currentElement)) {
				System.out.println("The largest palindrome as a product of two three digit numbers is: " + currentElement);	
				System.out.println("The numbers are " + one + " and " + two);
				break;
			}
			index--;
		}
	}
	
	//Tests if the int is a palindrome
	public boolean isPalindrome(int num) {
		boolean palindrome = true;
				
		int holderNum = num;
		
		LinkedList<Integer> stack = new LinkedList<Integer>();
		
		while(holderNum > 0) {
			stack.push(holderNum % 10);
			holderNum /= 10;
		}
		
		int[] digits = new int[stack.size()];
		int stackCount = stack.size();
		
		for(int i = 0; i < stackCount; i++) {
			digits[i] = stack.pop();
		}
		
		for(int index = 0; index < digits.length / 2; index++) {
			if(index == digits.length - (index + 1)) {
				palindrome = true;
				break;
			}
			else if(!(digits[index] == digits[digits.length - (index + 1)])) {
				palindrome = false;
				break;
			}
			else {
				//Keep going
			}
		}
		return palindrome;
	}
	
	//Borrowed from LargestPrimeFactor.java
	public LinkedList<Integer> findFactors(int input) {
		LinkedList<Integer> allFactors = new LinkedList<Integer>();
		
		//If you start with i, the largest factor you'll ever get to is input/i
		//Much better than simply going to the half point!
		for(int i = 1; i <= input/i; i++) {
			if(input % i == 0 && getDegree(i) == 3)
				allFactors.add(i);
		}
		return allFactors;
	}
	
	public int getDegree(int input) {
		int numStorage = input;
		int degree = 0;
		
		while(numStorage > 0) {
			numStorage /= 10;
			degree++;
		}
		return degree;
	}
	
	public boolean hasTwoThreeDigits(LinkedList<Integer> input, int inputNumber) {
		boolean twoThreeDigits = false;
		
		int degree;
		for(int index = 0; index < input.size(); index++) {
			
			degree = getDegree(input.get(index));
			if(degree != 3); //do nothing
			else {
				degree = getDegree(inputNumber / input.get(index));
				if(degree == 3) {
					twoThreeDigits = true;
					one = input.get(index);
					two = inputNumber / input.get(index);
					break;
				}
			}
		}
		return twoThreeDigits;
	}
}