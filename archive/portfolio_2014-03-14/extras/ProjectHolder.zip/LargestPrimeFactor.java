import java.util.*;

//Very fun problem

//Find out how to not use ArrayList as that is un-necessary memory allocation
//Arrays would be the best structure in this case.
public class LargestPrimeFactor {

	public LargestPrimeFactor() {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a number to find the largest prime factor of ");
		double input = scan.nextDouble();
		
		ArrayList factorHolder = findFactors(input);
		
		System.out.println("All the factors: ");
		for(int u = 0; u < factorHolder.size(); u++) {
			System.out.println(factorHolder.get(u));
		}
		
		ArrayList primeHolder = findPrimes(factorHolder);
		for(int i = 0; i < primeHolder.size(); i++) {
			System.out.println("The Prime Factors are: " + primeHolder.get(i));
		}
		
		int largestPrime = 0;
		
		for(int x = 0; x < primeHolder.size(); x++) {
			if((int) primeHolder.get(x) > largestPrime) {
				largestPrime = (int) primeHolder.get(x);
			}
		}
		System.out.println("The largest prime factor to " + input + " is " + largestPrime);
	}
	
	public ArrayList findFactors(double input) {
		ArrayList allFactors = new ArrayList();
		
		//what's a more efficient way to find factors of a number?
		//try counting only up to the half point!
		
		//If you start with i, the largest factor you'll ever get to is input/i
		//Much better than simply going to the half point!
		for(int i = 1; i <= input/i; i++) {
			System.out.println("Inside findFactors, input: " + input);
			if(input % i == 0) {
				allFactors.add(i);
				System.out.println("allFactors added " + i + " as a factor");
			}
		}
		
		return allFactors;
	}
	
	public ArrayList findPrimes(ArrayList allTheFactors) {
		ArrayList primeHolder = new ArrayList();
		
		for(int i = 0; i < allTheFactors.size(); i++) {
			if(findFactors((int) allTheFactors.get(i)).size() <= 1) {
				primeHolder.add(allTheFactors.get(i));
				System.out.println("Just added the prime number " + allTheFactors.get(i));
			}
		}
		return primeHolder;
	}
}
