import java.util.*;


//**UNFINISHED**

/*
 * PigLatinTranslater takes input words, finds the first consonant sound
 * (up until the first vowel) and subtracts that from the beginning of the 
 * word, then adds it to the end of the existing word while adding the 
 * phrase 'ay' at the very end.
 */
public class PigLatinTranslator {
	private String line;
	
	public PigLatinTranslator() {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a string so I can translate it!");
		line = scan.nextLine();
		
		System.out.println("Ok, I'm translating it!");
		separateWords(line);		
	}
	
	/*
	 * Takes the input line and translates it to pig-Latin. 
	 * Assumes words are separated by spaces.
	 */
	public void separateWords(String inputLine) {
		String mainHolder, holder;
		mainHolder = holder = "";
		
		int previousIndex = 0;
		
		for(int currentIndex = 0; currentIndex < inputLine.length(); currentIndex++) {
			while(inputLine.charAt(currentIndex) != ' ' && !(currentIndex >= inputLine.length() - 1)) {
				currentIndex++;
			}
			
			//Find a way to work around this
			if(currentIndex >= inputLine.length() - 1)
				currentIndex++;
			
			holder = inputLine.substring(previousIndex, currentIndex);
			
			System.out.println("This is the word before translation! " + holder);
			mainHolder = mainHolder.concat(translate(holder));
			holder = "";
			previousIndex = currentIndex + 1;
		}
	}
	
	//Translate the input word to pig Latin
	public String translate(String holder) {
		String translatedWord = "";
		boolean allChars = true;
		
		//make sure there are only characters
		for(int i = 0; i < holder.length(); i++) {
			if(!((holder.charAt(i) < 90 && holder.charAt(i) > 65)
					|| (holder.charAt(i) < 125 && holder.charAt(i) > 97))) {
				System.out.println("There's something in here that's not a character!");
				allChars = false;
				break;
			}
		}
		//Knowing there are no characters other than alphabetical symbols, translate it
		if(allChars) {
			System.out.println("Hey, you made it to allChars!");
		}
		
		
		return translatedWord;
	}
}
