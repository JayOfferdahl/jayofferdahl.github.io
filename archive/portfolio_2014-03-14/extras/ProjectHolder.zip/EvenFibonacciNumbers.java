import java.util.*;


public class EvenFibonacciNumbers {

	public EvenFibonacciNumbers() {
		Scanner scan = new Scanner(System.in);
		
		int toCountTo = 4000000;
		
		int previousTerm, currentTerm, holder, totalSum;
		previousTerm = currentTerm = 1;
		
		holder = totalSum = 0;
		
		while(currentTerm < toCountTo) {
			holder = previousTerm + currentTerm;
			
			previousTerm = currentTerm;
			currentTerm = holder;
			
			System.out.println("The current sum is " + holder);
			
			if(holder % 2 == 0)
				totalSum += holder;
			
			System.out.println("The total sum is " + totalSum);
			
		}
	}
}
